from kafka import KafkaConsumer, KafkaProducer
import json


def setup_kafka():
    producer = KafkaProducer(bootstrap_servers='localhost:9092',
                             key_serializer=str.encode,
                             value_serializer=lambda v: json.dumps(v).encode('utf-8'))

    consumer = KafkaConsumer(bootstrap_servers=['localhost:9092'],
                             value_deserializer=json.loads,
                             key_deserializer=bytes.decode)

    consumer.subscribe(['video', 'servos', 'algorithm'])

    return producer, consumer


class StoryTeller:
    def __init__(self, story_config, session, mode, kafka_producer, kafka_consumer):
        self.story_name = story_config['name']
        self.pages = story_config['pages']
        self.actions = story_config['actions']
        self.session = session
        self.manual = True if mode == 'manual' else False
        self.producer = kafka_producer
        self.consumer = kafka_consumer
        self.current_page = 0

    def play(self):
        # run video
        print(f'Playing page', self.current_page, '/', len(self.pages))
        self.producer.send('video', value={'page': str(self.current_page + 1), 'story': self.story_name, 'status': 'play'}, key='StoryTeller')
        self.current_page += 1

    def page_end(self, page_num):
        if page_num >= len(self.pages):
            print('story ended')
            pass
        else:
            if self.manual:
                self.producer.send('app', value={'command': 'GetAction', 'status': 'EoP'}, key='StoryTeller')
            else:
                self.producer.send('algorithm', value={'command': 'GetAction', 'session': str(self.session)}, key='StoryTeller')


producer, consumer = setup_kafka()
consumer.subscribe(['video', 'algorithm', 'servos'])
story = None

for message in consumer:
    if message.topic == 'storyteller' and message.key == 'app':    # new story start
        if message.value['command'] == 'play':
            story = StoryTeller(message.value['config'],
                                session=message.value['session'],
                                mode=message.value['mode'],
                                kafka_producer=producer,
                                kafka_consumer=consumer)
            story.play()

    if message.topic == 'video' and message.key == 'VideoService' and message.value['status'] == 'EoP' and story is not None:
        print('page ended, whats next?')
        if story.manual:
            producer.send(topic='storyteller', value = {'status': 'EoP', 'page': story.current_page}, key='StoryTeller')

        else:
            pass
            producer.send(topic='algorithm', value={'status': 'EoP', 'page': story.current_page}, key='StoryTeller')

